<template>
	<div>首页T</div>
</template>

<script>
	export default({
//		created(){
//			document.addEventListener('online', function () {
////			    alert('网络连接成功');
//			    if (navigator.connection.type == Connection.WIFI) {
////			        alert('已经切换到Wifi网络');
//			    }
//			}, false);
//		}
	})
</script>

<style>
</style>