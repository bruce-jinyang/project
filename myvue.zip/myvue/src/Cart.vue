<template>
<div id="cart">
	cart
</div>
</template>

<script>
	export default {
  name: 'Cart'
}
</script>

<style>
</style>